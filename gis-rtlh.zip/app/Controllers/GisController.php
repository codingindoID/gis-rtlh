<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\GisModel;

class GisController extends BaseController
{
    protected $modelPeta;
    public function __construct()
    {
        $this->modelPeta = new GisModel();
    }

    public function index()
    {
        $data = [
            'active'    => 'master-map',
            'map'       => $this->modelPeta->findAll()
        ];
        $this->temp->render('gis/index', $data);
    }

    public function map()
    {
        $data = [
            'active'    => 'map'
        ];
        $this->temp->render('gis/map', $data);
    }

    function add()
    {
        $data = [
            'active'        => 'master-map',
            'validation'    => session('validation')
        ];
        $this->temp->render('gis/form', $data);
    }

    function save()
    {
        $var = $this->request->getVar();
        $gambar = $this->request->getFile('gambar');

        if ($gambar->getName() != "") {
            $rule = [
                'gambar' => [
                    'label' => 'gambar Lokasi',
                    'rules' => [
                        'is_image[gambar]',
                        'max_size[gambar,2024]',
                        'mime_in[gambar,image/jpg,image/jpeg,image/gif,image/png,image/webp]',
                    ],
                    'errors' => [
                        'is_image'  => 'File Lokasi Harus Berupa Gambar',
                        'max_size'  => 'Maksimal File Yang Diijinkan Adalah 2MB',
                        'mime_in'   => 'File Lokasi Harus Berupa Gambar',
                    ]
                ],
            ];
            if (!$this->validate($rule)) {
                return redirect()->back()->withInput()->with('validation', $this->validation->getErrors());
            }

            $img = $this->request->getFile('gambar');
            $newName = $img->getRandomName();
            $path = 'uploads/map/';
            if (!is_dir($path)) {
                mkdir($path, 0777, true);
            }

            $var['gambar'] = $newName;
            //pindah Image Ke path Yang sudah Benar
            $img->move($path, $newName);

            //hapus old image
            if ($var['id']) {
                $gambar = $this->modelPeta->where('id', $var['id'])->first();
                $path = './' . PATHUPLOADMAP . $gambar->gambar;
                if (file_exists($path) && $gambar->gambar != null) {
                    unlink($path);
                }
            }
        }
        $this->modelPeta->save($var);
        return redirect()->to('gis')->with('success', 'Data RTLH berhasil disimpan');
    }

    function delete()
    {
        $var = $this->request->getVar();
        //cari file
        $gambar = $this->modelPeta->where('id', $var['id'])->first();
        $path = './' . PATHUPLOADMAP . $gambar->gambar;
        if (file_exists($path) && $gambar->gambar != null) {
            unlink($path);
        }

        $this->modelPeta->where('id', $var['id'])->delete();
        return redirect()->to('gis')->with('success', 'Data RTLH berhasil dihapus');
    }

    function edit($id)
    {
        $data = [
            'active'        => 'master-map',
            'validation'    => session('validation'),
            'map'           => $this->modelPeta->where('id', $id)->first()
        ];
        // dd($data);
        $this->temp->render('gis/form', $data);
    }

    function cariLokasi()
    {
        $var = $this->request->getVar();
        //cari data sesuai
        $data = $this->modelPeta->where('nama_lokasi', $var['nama_lokasi'])->first();
        if (!$data) {
            //jika data kosong maka cari data yang menyerupai
            $data = $this->modelPeta->like('nama_lokasi', $var['nama_lokasi'])->first();
        }
        if (!$data) {
            return redirect()->back()->with('warning', 'lokasi tidak ditemukan atau belum terdaftar dalam database');
        }

        $data = [
            'active'    => 'map',
            'map'       => $data,
            'param'     => $var['nama_lokasi']
        ];
        $this->temp->render('gis/map', $data);
    }

    /* AJAX */
    function ajaxMap()
    {
        $data =  $this->modelPeta->findAll();
        return $this->response->setStatusCode(200)->setJSON($data);
    }

    function ajaxMapDetil($id)
    {
        $data =  $this->modelPeta->where('id', $id)->first();
        return $this->response->setStatusCode(200)->setJSON($data);
    }
}
