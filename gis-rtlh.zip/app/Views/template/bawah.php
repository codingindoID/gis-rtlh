</div>
</div>

<?= view('template/pars/footer') ?>
</div>
</div>
<?= view('template/pars/js') ?>
</body>

</html>