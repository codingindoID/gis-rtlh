<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">SimRtlh-GIS</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">R-GIS</a>
        </div>
        <ul class="sidebar-menu">
            <li class="<?= $active == 'dashboard' ? 'active' : '' ?>"><a class="nav-link " href="<?= base_url() ?>"><i class="fas fa-columns"></i> <span>Dashboard</span></a></li>
            <li class="<?= $active == 'map' ? 'active' : '' ?>"><a class="nav-link" href="<?= base_url('gis/map') ?>"><i class="fas fa-map"></i> Data Rtlh</a></li>
            <li class="<?= $active == 'master-map' ? 'active' : '' ?>"><a class="nav-link" href="<?= base_url('gis') ?>"><i class="fas fa-database"></i> Master Data RTLH</a></li>
            <li class="<?= $active == 'master-user' ? 'active' : '' ?>"><a class="nav-link" href="<?= base_url('users') ?>"><i class="fas fa-users"></i> Master Data Pengguna</a></li>
        </ul>
    </aside>
</div>