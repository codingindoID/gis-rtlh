<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2023 <div class="bullet"></div> Themes By <a href="https://github.com/stisla/stisla">stisla</a>
    </div>
    <div class="footer-right">

    </div>
</footer>