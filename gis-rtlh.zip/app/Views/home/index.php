<div class="row">
    <div class="col-md-4">
        <div class="card card-body hover bg-primary position-relative" onclick="location.href='<?= base_url('gis') ?>'">
            <p>LOKASI RTLH</p>
            <h2><?= $countrtlh ?></h2>
            <img src="<?= base_url('assets/img/map.png') ?>" alt="" class="w-100 position-absolute" style="max-width: 100px; right: 10px; top: 10px;">
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-body hover bg-info position-relative" onclick="location.href='<?= base_url('users') ?>'">
            <p>PENGGUNA APLIKASI</p>
            <h2><?= $countuser ?></h2>
            <img src="<?= base_url('assets/img/man.png') ?>" alt="" class="w-100 position-absolute" style="max-width: 100px; right: 10px; top: 10px;">
        </div>
    </div>
</div>