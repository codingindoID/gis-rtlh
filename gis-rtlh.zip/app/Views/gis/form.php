<style>
    #map {
        height: 60vh;
    }
</style>
<h5>Form Tambah Data LOKASI RTLH</h5>

<div class="row">
    <div class="col-6">
        <form action="<?= base_url('gis/save') ?>" method="post" enctype="multipart/form-data">
            <div class="row">
                <input type="hidden" name="id" value="<?= isset($map->id) ? $map->id : '' ?>">
                <div class="col-12">
                    <div class="form-group">
                        <label for="">Nama Lokasi</label>
                        <input type="text" name="nama_lokasi" class="form-control" value="<?= isset($map->nama_lokasi) ? $map->nama_lokasi : '' ?>">
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label for="">Keterangan Lokasi</label>
                        <textarea name="keterangan" rows="4" class="form-control"><?= isset($map->keterangan) ? $map->keterangan : '' ?></textarea>
                    </div>
                </div>
                <div class="col-5">
                    <div class="form-group">
                        <label for="">Latitude</label>
                        <input type="text" name="latitude" id="lat" class="form-control" value="<?= isset($map->latitude) ? $map->latitude : '' ?>">
                    </div>
                </div>
                <div class="col-5">
                    <div class="form-group">
                        <label for="">Longitude</label>
                        <input type="text" name="longitude" id="leng" class="form-control" value="<?= isset($map->longitude) ? $map->longitude : '' ?>">
                    </div>
                </div>
                <div class="col-2">
                    <div class="form-group">
                        <label for="">Cek Titik</label>
                        <button onclick="cekMarker()" class="btn btn-warning">Cek</button>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label for="">Gambar Lokasi</label>
                        <input type="file" name="gambar" class="form-control <?= isset($validation['gambar']) ? 'is-invalid' : '' ?>">
                        <div class="invalid-feedback">
                            <?= isset($validation['gambar']) ? $validation['gambar'] : '' ?>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Simpan Data</button>
                </div>
            </div>
        </form>
    </div>
    <div class="col-6">
        <div id="map"></div>
    </div>
</div>

<script>
    let base = $('#base_url').data('id')
    let latitude = $('#lat').val()
    let longitude = $('#leng').val()

    latitute = latitude ? latitude : "-6.5897518";
    longitude = longitude ? longitude : "110.6651467";
    let latleng = [latitute, longitude]
    let map = L.map('map').setView(latleng, 13);
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Dev By : <a target="__blank" href="https://pengenngoding.com">PengenNgoding</a>',
        maxZoom: 20,
        id: 'mapbox/satellite-streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoiY29kaW5naW5kb2plcGFyYSIsImEiOiJjbDA2cDM1NWgwNGIwM2JwZDNsdzltMTdjIn0.wt3TChqH_CNIvj5PsgzwXA'
    }).addTo(map);

    let marker = L.marker(latleng).addTo(map);
    map.on('click', function(e) {
        lat = e.latlng.lat;
        lon = e.latlng.lng;
        if (marker != undefined) {
            map.removeLayer(marker);
        };

        //Add a marker to show where you clicked.
        marker = L.marker([lat, lon]).addTo(map);
        $('#lat').val(lat)
        $('#leng').val(lon)
    });

    function cekMarker() {
        let lat = $('#lat').val()
        let lon = $('#leng').val()
        if (marker != undefined) {
            map.removeLayer(marker);
        };

        //Add a marker to show where you clicked.
        marker = L.marker([lat, lon]).addTo(map);
        $('#lat').val(lat)
        $('#leng').val(lon)
    }
</script>