<style>
    #map {
        height: 70vh;
    }
</style>
<form action="<?= base_url('gis/cari-lokasi') ?>" method="post">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="">Cari Lokasi RTLH</label>
                <input type="text" name="nama_lokasi" class="form-control" placeholder="Inputkan Nama Lokasi" value="<?= isset($param) ? $param : '' ?>">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="" class="w-100"> &nbsp; </label>
                <button type="sumbit" class="btn btn-warning"><i class="fa fa-map"></i> Cari Lokasi</button>
            </div>
        </div>
    </div>
</form>
<div id="lat-cari" data-val="<?= isset($map->latitude) ? $map->latitude : '' ?>"></div>
<div id="long-cari" data-val="<?= isset($map->longitude) ? $map->longitude : '' ?>"></div>
<div id="id-cari" data-val="<?= isset($map->id) ? $map->id : '' ?>"></div>
<div id="map"></div>

<div class="modal fade" id="modalMap" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detil Lokasi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <img id="gambar_lokasi" src="<?= base_url('assets/img/default-map.jpg') ?>" alt="" class="w-100">
                        <hr>
                        <small>Nama Lokasi</small>
                        <p id="nama_lokasi"></p>
                        <small>Keterangan Lokasi</small>
                        <p id="keterangan"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    let base = $('#base_url').data('id')
    let latitude = $('#lat-cari').data('val')
    let longitude = $('#long-cari').data('val')
    let id = $('#id-cari').data('val')
    latitude = latitude ? latitude : "-6.5897518";
    longitude = longitude ? longitude : "110.6651467";

    let latleng = [latitude, longitude]
    let map = L.map('map').setView(latleng, 13);
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Dev By : <a target="__blank" href="https://pengenngoding.com">PengenNgoding</a>',
        maxZoom: 20,
        id: 'mapbox/satellite-streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoiY29kaW5naW5kb2plcGFyYSIsImEiOiJjbDA2cDM1NWgwNGIwM2JwZDNsdzltMTdjIn0.wt3TChqH_CNIvj5PsgzwXA'
    }).addTo(map);

    if (id != '') {
        $.ajax({
            type: "get",
            url: `${base}ajax-map-detil/${id}`,
            dataType: "json",
            success: function(response) {
                if (response) {
                    let gambar = base + 'assets/img/default-map.jpg'
                    if (response.gambar != null) {
                        gambar = base + 'uploads/map/' + response.gambar
                    }
                    $('#gambar_lokasi').attr('src', gambar)
                    $('#nama_lokasi').text(response.nama_lokasi)
                    $('#keterangan').text(response.keterangan)

                    $('#modalMap').modal('show')
                }
            }
        });
    }

    $.ajax({
        type: "get",
        url: `${base}ajax-map`,
        dataType: "json",
        success: function(response) {
            if (response.length > 0) {
                for (let index = 0; index < response.length; index++) {
                    let array = [String(response[index].latitude), String(response[index].longitude)]
                    let marker = L.marker(array);
                    marker.bindTooltip(response[index].nama_lokasi, {
                        permanent: true,
                        className: "my-label",
                        offset: [0, 0]
                    });
                    marker.addTo(map);
                    marker.on('click', function(ev) {
                        let gambar = base + 'assets/img/default-map.jpg'
                        if (response[index].gambar != null) {
                            gambar = base + 'uploads/map/' + response[index].gambar
                        }
                        $('#gambar_lokasi').attr('src', gambar)
                        $('#nama_lokasi').text(response[index].nama_lokasi)
                        $('#keterangan').text(response[index].keterangan)

                        $('#modalMap').modal('show')
                    });
                }
            }
        }
    });
</script>